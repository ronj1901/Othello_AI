// expmain.cpp
//
// ICS 46 Spring 2017
// Project #2: Black and White
//
// Do whatever you'd like here.  This is intended to allow you to experiment
// with the given classes in the darkmaze library, or with your own
// algorithm implementations, outside of the context of the GUI or
// Google Test.
#include <ics46/factory/DynamicFactory.hpp>

#include "SamOthelloAI.hpp"

int main()
{


  
	// std::unique_ptr<OthelloGameState> state =
 //        OthelloGameStateFactory{}.makeNewGameState(8, 8);

	// MyOthelloAI AI;

 //     std::vector<std::pair<int, int>> move = AI.chooseMove(*state);
 //     state->makeMove(move.first, move.second);

    return 0;
}

